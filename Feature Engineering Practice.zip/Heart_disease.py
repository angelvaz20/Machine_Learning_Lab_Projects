#Name: Angel Vasquez
#Parnter name: Juan Hernandez
import pandas as pd 
from sklearn.preprocessing import LabelEncoder 
from sklearn import preprocessing 
df = pd.read_csv('Heart_disease.csv') #Heart_disease from UCI Dataset

print(df)

#show missing values
print(df.isnull().sum()) # the output of the code is that there are missing values in thal,and ca

# 1. Fill 'ca' with the most common value becasue discrete data
# .mode() returns a list, so [0] grabs the single most common number
ca_mode = df['ca'].mode()[0]
df['ca'] = df['ca'].fillna(ca_mode)

# 2. Fill 'thal' with the most common value
thal_mode = df['thal'].mode()[0]
df['thal'] = df['thal'].fillna(thal_mode)

# Verify the changes
print("Missing values after fill:")
print(df[['ca', 'thal']].isnull().sum())
print(df)

#Colum Manipulation
old_cols = df.columns.values
new_cols = ['sex', 'age', 'num','thal','ca','slope','oldpeak','exang','thalach','restecg','fbs','chol', 'trestbps']
df = df.reindex(columns=new_cols)
print(df)

#Rename Column 
df = df.rename(columns={'sex': 'Gender', 'age': 'Age'})
print(df.rename(columns={'sex':'Gender','age':'Age'}))





#Creating an insance of Label Encoder
le = LabelEncoder()

# Using .fit_transform function to fit label
# encoder and return encoded label
label = le.fit_transform(df['fbs'])
df['fbs'] = le.fit_transform(df['fbs'])


print(df)