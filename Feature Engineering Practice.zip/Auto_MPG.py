#Name: Angel Vasquez
#Parnter name: Juan Hernandez
import pandas as pd
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder


df = pd.read_csv('Auto_MPG.csv')

print(df)

print(df.isnull().sum())
# Force horsepower to be numbers, turning errors into NaNs
df['horsepower'] = pd.to_numeric(df['horsepower'], errors='coerce')

# Now fill the NaNs with average .mean()
df = df.fillna(df.mean())



#Verify changes, now there are 0 missing values
print(df.isnull().sum())

#Data Standardization/Normalization
#standardize the data
df_scaled = preprocessing.scale(df)

#after the standardization, we bring it back to the pandas dataframe
df_scaled=pd.DataFrame(df_scaled,columns=df.columns)

#since we do not want to scale the MPG column (which is the target variable that we are tryping to predict)
#let's use the original MPG column

df_scaled['mpg'] = df['mpg']
df=df_scaled
print(df)

