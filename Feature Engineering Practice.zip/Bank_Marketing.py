#Name: Angel Vasquez
#Parnter name: Juan Hernandez
import pandas as pd
from sklearn.preprocessing import LabelEncoder
df = pd.read_csv('bankmarketing.csv')

print(df)

#Check Missing Values
print(df.isnull().sum())

#Fill missing categorical data as unknown
df['contact'] = df['contact'].fillna('unknown')
df['poutcome'] = df['poutcome'].fillna('unknown')
df['education'] = df['education'].fillna('unknown')
df['job'] = df['job'].fillna('unknown')


#Common numeric column with missing values
df['pdays'] = df['pdays'].fillna(df['pdays'].median())

#creating an instnace of label encoder 
le = LabelEncoder()

#changing the yes and no's to 0 and 1s for housing (0 = no, 1 = yes)
labe0 = le.fit_transform(df['housing']) #using .fit_tranform function to fit label encoder and return encoded label
df.drop('housing', axis=1, inplace=True) #removing the column 'housing' from  df (no more use)
df['housing'] = labe0 #change it to new column 'housing'

#changing the yes and no's to 0 and 1s for loan (0 = no, 1 = yes) 
label1 = le.fit_transform(df['loan']) #using .fit_tranform function to fit label encoder and return encoded label
df.drop('loan', axis=1, inplace=True) #removing the column 'loan' from  df (no more use)
df['loan'] = label1  #change it to new column 'laon'

label2 = le.fit_transform(df['default'])
df.drop('default', axis=1, inplace=True)
df['default'] = label2


label4 = le.fit_transform(df['y'])
df.drop('y', axis=1, inplace=True)
df['y'] = label4

df = pd.get_dummies(
    df,
    columns=['job', 'education', 'marital', 'contact', 'poutcome', 'month', 'day_of_week'],
    drop_first=True
)

print(df)