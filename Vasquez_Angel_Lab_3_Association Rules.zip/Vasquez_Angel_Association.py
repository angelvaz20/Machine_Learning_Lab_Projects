import pandas as pd  #Import pandas library
from mlxtend.preprocessing import TransactionEncoder  #Import TransactionEncoder to convert transactions into one-hot format
from mlxtend.frequent_patterns import apriori, association_rules  
#Import apriori algorithm to find frequent itemsets
#Import association_rules to generate rules from frequent itemsets


def items_to_text(items_set):
    return ", ".join(sorted(list(items_set)))  
    #Convert a set of items (like {'milk','bread'}) into a readable string
    #Steps:
    #1. Convert set to list
    #2. Sort alphabetically
    #3. Join items into a comma-separated string


def support_of_itemset(onehot_df, items):
    if len(items) == 0:
        return 0.0  
        #If no items provided, support is 0

    return onehot_df[list(items)].all(axis=1).mean()
    #Select the columns for the given items
    #.all(axis=1) checks if ALL items exist in each row (transaction)
    #.mean() converts True/False to 1/0 and averages them
    #Result = proportion of transactions containing that itemset (support)


def main():
    csv_path = "groceries.csv"  #Path to your dataset file

    min_support = 0.02    #Minimum percentage of transactions an itemset must appear in (2%)
    min_confidence = 0.30    #Minimum rule confidence (30%)

    df = pd.read_csv(csv_path)   #Read the CSV file into a pandas DataFrame 
    df = df.dropna(subset=["Items"])   #Remove rows where the "Items" column is missing

    transactions = [] #Create empty list to store each transaction as a list of items
    for transaction_text in df["Items"]:  #Loop through each row in the "Items" column
        raw_items = str(transaction_text).split(",")    #Convert row to string and split by comma into individual items
        clean_items = []   #Create empty list to store cleaned items for this transaction
        for item in raw_items:   #Loop through each item in the split list
            item = item.strip()    #Remove extra spaces before and after item names
            if item != "":  #Ignore empty strings
                clean_items.append(item)     #Add cleaned item to transaction list
        transactions.append(clean_items)  
        #Add this cleaned transaction to master transactions list


    te = TransactionEncoder()   #Create TransactionEncoder object
    te_array = te.fit(transactions).transform(transactions)   #Learn all unique items (fit) #Convert transactions into True/False matrix (transform)
    onehot = pd.DataFrame(te_array, columns=te.columns_) #Convert boolean matrix into pandas DataFrame, Learn all unique items (fit)


    frequent_itemsets = apriori(onehot, min_support=min_support, use_colnames=True)  #Run Apriori algorithm to find itemsets meeting minimum support
    #Run Apriori algorithm to find itemsets meeting minimum support
    #use_colnames=True shows item names instead of column numbers
    frequent_itemsets = frequent_itemsets.sort_values("support", ascending=False) #Sort frequent itemsets by highest support first


    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence) #Generate association rules using confidence as the main metric
    #Only keep rules with confidence >= min_confidence

    rules = rules.sort_values(["lift", "confidence"], ascending=False) #Sort rules by lift first, then confidence


    print("DATASET")
    print("Transactions:", len(transactions))  #Print number of total transactions
    print("Unique items:", onehot.shape[1])  #Print number of unique items (number of columns)
    print()

    print("APRIORI SETTINGS")
    print("min_support   =", min_support)  #Print support threshold
    print("min_confidence=", min_confidence)  #Print confidence threshold
    print()


    print("FREQUENT ITEMSETS (top 10)")
    if frequent_itemsets.empty:
        print("No frequent itemsets found. Try lowering min_support.")
        return  
        #Stop program if no frequent itemsets found
    frequent_print = frequent_itemsets.copy()  #Make copy so original data isn't modified
    frequent_print["itemsets"] = frequent_print["itemsets"].apply(items_to_text) #Convert frozensets into readable text
    frequent_print["support"] = frequent_print["support"].round(4) #Round support to 4 decimal places

    print(frequent_print[["support", "itemsets"]].head(10).to_string(index=False)) #Print top 10 frequent itemsets
    print()

    print("ASSOCIATION RULES (top 10)")
    if rules.empty:
        print("No rules found. Try lowering min_support or min_confidence.")
        return  
        #Stop program if no rules found


    rules_print = rules[["antecedents", "consequents", "support", "confidence", "lift", "conviction"]].copy()   #Select important rule columns
    rules_print["antecedents"] = rules_print["antecedents"].apply(items_to_text)    #Convert antecedent sets to readable text
    rules_print["consequents"] = rules_print["consequents"].apply(items_to_text)    #Convert consequent sets to readable text
    rules_print["support"] = rules_print["support"].round(4)
    rules_print["confidence"] = rules_print["confidence"].round(4)
    rules_print["lift"] = rules_print["lift"].round(4)
    rules_print["conviction"] = rules_print["conviction"].round(4)
    #Round metrics for cleaner display

    print(rules_print.head(10).to_string(index=False)) #Print top 10 rules
    print()

    print("METRIC DEFINITIONS (for a rule A -> B)")
    print("support(A)   = P(A)")
    print("support(A∪B) = P(A and B)")
    print("confidence   = P(B|A) = support(A∪B) / support(A)")
    print("lift         = confidence / support(B)")
    print("conviction   = (1 - support(B)) / (1 - confidence)")
    print()


    example = rules.iloc[0]   #Select top rule (first row)
    A = example["antecedents"]  #Extract antecedent
    B = example["consequents"]  #Extract consequent

    support_A = support_of_itemset(onehot, A)   #Manually compute support of A
    support_B = support_of_itemset(onehot, B)   #Manually compute support of B
    support_AB = support_of_itemset(onehot, set(A) | set(B)) #Compute support of A union B

    confidence = 0.0 if support_A == 0 else support_AB / support_A  #Compute confidence manually
    lift = 0.0 if support_B == 0 else confidence / support_B   #Compute lift manually
    conviction = float("inf") if confidence == 1 else (1 - support_B) / (1 - confidence) #Compute conviction manually


    print("EXAMPLE (manual calculation for the top rule)")
    print("A (antecedent):", items_to_text(A))
    print("B (consequent):", items_to_text(B))
    print("support(A)     =", round(support_A, 4))
    print("support(B)     =", round(support_B, 4))
    print("support(A∪B)   =", round(support_AB, 4))
    print("confidence     = support(A∪B) / support(A)     =", round(confidence, 4))
    print("lift           = confidence / support(B)      =", round(lift, 4))
    if conviction == float("inf"):
        conviction_text = "inf"
    else:
        conviction_text = str(round(conviction, 4))
    print("conviction     = (1-support(B)) / (1-confidence)=", conviction_text)
    
if __name__ == "__main__":
    main()  
    # Run the main function when the script is executed
